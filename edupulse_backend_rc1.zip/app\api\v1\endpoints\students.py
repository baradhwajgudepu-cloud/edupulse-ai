import uuid
from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status, HTTPException

from app.api.dependencies.common import get_tenant_id, verify_school_access
from app.api.dependencies.student import get_student_service
from app.api.dependencies.auth import require_permission
from app.services.student import StudentService
from app.schemas.student import StudentCreate, StudentUpdate, StudentResponse
from app.models.student import StudentStatus
from app.models.user import User
from app.schemas.response import APIResponse

router = APIRouter()

@router.post(
    "",
    response_model=APIResponse[StudentResponse],
    status_code=status.HTTP_201_CREATED,
    summary="Register a new student",
    description="Registers a new student profile in the system under Class/Section boundaries, checking capacities."
)
async def create_student(
    obj_in: StudentCreate,
    tenant_id: uuid.UUID = Depends(get_tenant_id),
    current_user: User = Depends(require_permission("student.create")),
    service: StudentService = Depends(get_student_service)
) -> APIResponse[StudentResponse]:
    await verify_school_access(current_user, obj_in.school_id, service.student_repo.db)
    db_obj = await service.create_student(tenant_id, obj_in, created_by=current_user.id)
    return APIResponse[StudentResponse](
        success=True,
        message="Student registered successfully.",
        data=StudentResponse.model_validate(db_obj)
    )

@router.get(
    "",
    response_model=APIResponse[List[StudentResponse]],
    status_code=status.HTTP_200_OK,
    summary="List student profiles under school",
    description="Retrieves a paginated list of students scoped by tenant, school, academic year, class, and section."
)
async def list_students(
    school_id: uuid.UUID = Query(..., description="Target school ID"),
    academic_year_id: Optional[uuid.UUID] = Query(None, description="Filter by Academic Year ID"),
    class_id: Optional[uuid.UUID] = Query(None, description="Filter by Class ID"),
    section_id: Optional[uuid.UUID] = Query(None, description="Filter by Section ID"),
    status_filter: Optional[StudentStatus] = Query(None, alias="status", description="Filter by student status"),
    search: Optional[str] = Query(None, description="Fuzzy match search on names, email, admission/roll codes, aadhaar, or mobile"),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    tenant_id: uuid.UUID = Depends(get_tenant_id),
    current_user: User = Depends(require_permission("student.read")),
    service: StudentService = Depends(get_student_service)
) -> APIResponse[List[StudentResponse]]:
    await verify_school_access(current_user, school_id, service.student_repo.db)
    role_codes = {r.code for r in current_user.roles}
    is_admin_or_principal = current_user.is_superuser or any(
        code in ["SUPER_ADMIN", "ADMIN", "SCHOOL_ADMIN", "PRINCIPAL", "TENANT_ADMIN", "CHAIRMAN"] for code in role_codes
    )
    class_section_pairs = None
    if not is_admin_or_principal and "TEACHER" in role_codes:
        from app.repositories.teacher import TeacherRepository
        from app.models.teacher_subject_assignment import TeacherSubjectAssignment, AssignmentStatus
        from sqlalchemy import select

        teacher_repo = TeacherRepository(service.student_repo.db)
        teacher = await teacher_repo.get_by_user_id(current_user.id, tenant_id)
        if not teacher:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied. No active teacher profile found for user."
            )

        if class_id and section_id:
            stmt_tsa = select(TeacherSubjectAssignment).where(
                TeacherSubjectAssignment.teacher_id == teacher.id,
                TeacherSubjectAssignment.class_id == class_id,
                TeacherSubjectAssignment.section_id == section_id,
                TeacherSubjectAssignment.status == AssignmentStatus.ACTIVE,
                TeacherSubjectAssignment.tenant_id == tenant_id
            )
            res_tsa = await service.student_repo.db.execute(stmt_tsa)
            tsa = res_tsa.scalar_one_or_none()
            if not tsa:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied. You are not assigned to this class and section."
                )
        else:
            stmt_tsa = select(TeacherSubjectAssignment.class_id, TeacherSubjectAssignment.section_id).where(
                TeacherSubjectAssignment.teacher_id == teacher.id,
                TeacherSubjectAssignment.status == AssignmentStatus.ACTIVE,
                TeacherSubjectAssignment.tenant_id == tenant_id
            )
            res_tsa = await service.student_repo.db.execute(stmt_tsa)
            assignments = res_tsa.all()
            if not assignments:
                return APIResponse[List[StudentResponse]](
                    success=True,
                    message="Students fetched successfully.",
                    data=[]
                )
            class_section_pairs = [(row.class_id, row.section_id) for row in assignments]

    students = await service.student_repo.get_multi(
        school_id=school_id,
        tenant_id=tenant_id,
        academic_year_id=academic_year_id,
        class_id=class_id,
        section_id=section_id,
        status=status_filter,
        search=search,
        class_section_pairs=class_section_pairs,
        skip=skip,
        limit=limit
    )
    responses = [StudentResponse.model_validate(s) for s in students]
    return APIResponse[List[StudentResponse]](
        success=True,
        message="Students fetched successfully.",
        data=responses
    )

@router.get(
    "/{id}",
    response_model=APIResponse[StudentResponse],
    status_code=status.HTTP_200_OK,
    summary="Get student details",
    description="Retrieves student profile attributes scoped by tenant and school."
)
async def get_student(
    id: uuid.UUID,
    school_id: uuid.UUID = Query(..., description="Target school ID"),
    tenant_id: uuid.UUID = Depends(get_tenant_id),
    current_user: User = Depends(require_permission("student.read")),
    service: StudentService = Depends(get_student_service)
) -> APIResponse[StudentResponse]:
    await verify_school_access(current_user, school_id, service.student_repo.db)
    db_obj = await service.student_repo.get_by_id(id, school_id, tenant_id)
    if not db_obj:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Student not found."
        )

    role_codes = {r.code for r in current_user.roles}
    is_admin_or_principal = current_user.is_superuser or any(
        code in ["SUPER_ADMIN", "ADMIN", "SCHOOL_ADMIN", "PRINCIPAL", "TENANT_ADMIN", "CHAIRMAN"] for code in role_codes
    )
    if not is_admin_or_principal and "TEACHER" in role_codes:
        from app.repositories.teacher import TeacherRepository
        from app.models.teacher_subject_assignment import TeacherSubjectAssignment, AssignmentStatus
        from sqlalchemy import select

        teacher_repo = TeacherRepository(service.student_repo.db)
        teacher = await teacher_repo.get_by_user_id(current_user.id, tenant_id)
        if not teacher:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied. No active teacher profile found for user."
            )
        stmt_tsa = select(TeacherSubjectAssignment).where(
            TeacherSubjectAssignment.teacher_id == teacher.id,
            TeacherSubjectAssignment.class_id == db_obj.class_id,
            TeacherSubjectAssignment.section_id == db_obj.section_id,
            TeacherSubjectAssignment.status == AssignmentStatus.ACTIVE,
            TeacherSubjectAssignment.tenant_id == tenant_id
        )
        res_tsa = await service.student_repo.db.execute(stmt_tsa)
        tsa = res_tsa.scalar_one_or_none()
        if not tsa:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied. You are not assigned to this student's class and section."
            )

    if not is_admin_or_principal and "PARENT" in role_codes:
        from app.models.guardian import Guardian, StudentGuardian
        from sqlalchemy import select, or_
        stmt_guard = select(StudentGuardian).join(Guardian).where(
            StudentGuardian.student_id == id,
            StudentGuardian.school_id == school_id,
            StudentGuardian.tenant_id == tenant_id,
            or_(
                Guardian.user_id == current_user.id,
                Guardian.email == current_user.email
            )
        )
        res_guard = await service.student_repo.db.execute(stmt_guard)
        if not res_guard.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied. You are not a linked guardian of this student."
            )

    return APIResponse[StudentResponse](
        success=True,
        message="Student details fetched successfully.",
        data=StudentResponse.model_validate(db_obj)
    )

@router.put(
    "/{id}",
    response_model=APIResponse[StudentResponse],
    status_code=status.HTTP_200_OK,
    summary="Update student details",
    description="Modifies student parameters scoped by tenant and school."
)
async def update_student(
    id: uuid.UUID,
    school_id: uuid.UUID = Query(..., description="Target school ID"),
    obj_in: StudentUpdate = ...,
    tenant_id: uuid.UUID = Depends(get_tenant_id),
    current_user: User = Depends(require_permission("student.update")),
    service: StudentService = Depends(get_student_service)
) -> APIResponse[StudentResponse]:
    await verify_school_access(current_user, school_id, service.student_repo.db)
    db_obj = await service.update_student(tenant_id, school_id, id, obj_in, updated_by=current_user.id)
    return APIResponse[StudentResponse](
        success=True,
        message="Student updated successfully.",
        data=StudentResponse.model_validate(db_obj)
    )

@router.delete(
    "/{id}",
    response_model=APIResponse[StudentResponse],
    status_code=status.HTTP_200_OK,
    summary="Soft-delete student profile",
    description="Soft-deletes the student profile, updating status to INACTIVE."
)
async def delete_student(
    id: uuid.UUID,
    school_id: uuid.UUID = Query(..., description="Target school ID"),
    tenant_id: uuid.UUID = Depends(get_tenant_id),
    current_user: User = Depends(require_permission("student.delete")),
    service: StudentService = Depends(get_student_service)
) -> APIResponse[StudentResponse]:
    await verify_school_access(current_user, school_id, service.student_repo.db)
    db_obj = await service.delete_student(tenant_id, school_id, id, deleted_by=current_user.id)
    return APIResponse[StudentResponse](
        success=True,
        message="Student deleted successfully.",
        data=StudentResponse.model_validate(db_obj)
    )
